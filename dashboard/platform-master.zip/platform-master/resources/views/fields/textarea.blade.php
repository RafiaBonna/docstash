<textarea {{ $attributes }}>{{ $value ?? '' }}</textarea>
