@if(strlen($value) > 0)
    <p {{ $attributes }}>
        {{ $value }}
    </p>
@endif
