<input type="range" class="form-range" {{ $attributes }}>
