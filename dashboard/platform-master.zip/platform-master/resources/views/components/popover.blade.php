<sup class="text-body-emphasis"
     role="button"
     data-controller="popover"
     data-bs-container="body"
     data-bs-toggle="popover"
     tabindex="0"
     data-bs-trigger="hover focus"
     data-bs-placement="{{ $placement }}"
     data-bs-delay-show="300"
     data-bs-delay-hide="200"
     data-bs-content="{{ $content }}">
    <x-orchid-icon path="bs.question-lg" width="1em" height="1em"/>
</sup>
