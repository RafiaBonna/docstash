<nav class="d-flex justify-content-center text-nowrap mb-3">
    <div class="bg-body-tertiary rounded overflow-hidden">
        <ul class="nav nav-pills nav-justified d-inline-flex mx-auto px-3 py-2 nav-scroll-bar gap-2">
            {!! $navigations !!}
        </ul>
    </div>
</nav>
