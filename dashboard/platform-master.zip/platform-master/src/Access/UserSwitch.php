<?php

declare(strict_types=1);

namespace Orchid\Access;

/**
 * @deprecated
 *
 * This class is deprecated and should not be used anymore.
 * Use the class Orchid\Access\Impersonation instead.
 */
class UserSwitch extends Impersonation {}
