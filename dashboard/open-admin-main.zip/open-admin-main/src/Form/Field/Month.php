<?php

namespace OpenAdmin\Admin\Form\Field;

class Month extends Date
{
    protected $format = 'MM';
}
